#!/bin/bash
# Quick test to verify build script setup

echo "========================================"
echo "  Build Script Verification"
echo "========================================"
echo ""

# Check if build script exists
if [ -f "/app/build_apk.py" ]; then
    echo "✓ Build script found: /app/build_apk.py"
else
    echo "✗ Build script not found!"
    exit 1
fi

# Check if script is executable
if [ -x "/app/build_apk.py" ]; then
    echo "✓ Build script is executable"
else
    echo "✗ Build script is not executable"
    exit 1
fi

# Check Python version
python_version=$(python3 --version 2>&1)
echo "✓ Python version: $python_version"

# Check Node.js
node_version=$(node --version 2>&1)
echo "✓ Node.js version: $node_version"

# Check Yarn
yarn_version=$(yarn --version 2>&1)
echo "✓ Yarn version: $yarn_version"

echo ""
echo "========================================"
echo "  Ready to Build!"
echo "========================================"
echo ""
echo "To build the APK, run:"
echo "  sudo python3 /app/build_apk.py"
echo ""
echo "Note: The build process will take 10-15 minutes"
echo ""
