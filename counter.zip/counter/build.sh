#!/bin/bash
# Simple wrapper script to build APK with better UI

clear
echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║                                                      ║"
echo "║     Counter App - Android APK Build Script          ║"
echo "║                                                      ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "⚠️  This script needs root privileges to install Android SDK"
    echo "   Please run: sudo /app/build.sh"
    echo ""
    exit 1
fi

echo "📱 Building Android APK for Counter App..."
echo ""
echo "This process will:"
echo "  1. Install Android SDK and build tools"
echo "  2. Configure the app for Android"
echo "  3. Build the APK file"
echo ""
echo "⏱️  Estimated time: 10-15 minutes"
echo ""
read -p "Press Enter to start the build process..."
echo ""

# Run the Python build script
python3 /app/build_apk.py

# Check if build was successful
if [ $? -eq 0 ]; then
    echo ""
    echo "╔══════════════════════════════════════════════════════╗"
    echo "║                                                      ║"
    echo "║         ✅ APK BUILD SUCCESSFUL! ✅                  ║"
    echo "║                                                      ║"
    echo "╚══════════════════════════════════════════════════════╝"
    echo ""
    echo "📦 Your APK is ready at: /app/counter-app.apk"
    echo ""
    echo "📲 To install on your Android device:"
    echo "   1. Download /app/counter-app.apk"
    echo "   2. Transfer to your Android phone"
    echo "   3. Enable 'Install from unknown sources'"
    echo "   4. Tap the APK to install"
    echo ""
else
    echo ""
    echo "╔══════════════════════════════════════════════════════╗"
    echo "║                                                      ║"
    echo "║         ❌ BUILD FAILED ❌                           ║"
    echo "║                                                      ║"
    echo "╚══════════════════════════════════════════════════════╝"
    echo ""
    echo "Please check the error messages above."
    echo "For help, see: /app/BUILD_INSTRUCTIONS.md"
    echo ""
    exit 1
fi
