# Android APK Build Instructions

## Quick Start

To build the Android APK for your Counter App, run:

```bash
sudo python3 /app/build_apk.py
```

## What the Script Does

The `build_apk.py` script will automatically:

1. ✓ Check prerequisites (Node.js, Yarn)
2. ✓ Install Android SDK and build tools (OpenJDK 17, Android SDK, Build Tools)
3. ✓ Configure your app for Android builds
4. ✓ Install necessary Expo dependencies
5. ✓ Run Expo prebuild to generate native Android code
6. ✓ Build the APK using Gradle
7. ✓ Copy the final APK to `/app/counter-app.apk`

## Build Time

The entire build process takes approximately **10-15 minutes** depending on your system speed and internet connection.

## Output

After successful build, you'll find the APK at:
- **Main location**: `/app/counter-app.apk`
- **Original location**: `/app/frontend/android/app/build/outputs/apk/release/`

## Installing on Android Device

1. Download the APK file from `/app/counter-app.apk`
2. Transfer it to your Android device (via USB, email, cloud storage, etc.)
3. On your Android device:
   - Go to **Settings** → **Security** → Enable **"Install from unknown sources"**
   - Find the APK file and tap to install
   - Follow the installation prompts
4. Launch the Counter App!

## Troubleshooting

### Build Fails
- Make sure you have enough disk space (at least 5GB)
- Ensure you run the script with `sudo`
- Check internet connection (downloads Android SDK components)

### APK Won't Install
- Enable "Install from unknown sources" in Android settings
- Make sure your Android version is 5.0 or higher

### Need Help?
Check the build logs for specific error messages. The script provides detailed output at each step.

## File Structure After Build

```
/app/
├── build_apk.py          # The build script
├── counter-app.apk       # Your final APK (after build)
├── frontend/
│   ├── android/          # Native Android code (generated)
│   ├── app/              # Your React Native code
│   └── ...
└── BUILD_INSTRUCTIONS.md # This file
```

## Notes

- This is a **preview build** suitable for testing
- The APK is not signed for Play Store release
- For production builds, you'll need to set up proper signing keys
- The build size will be approximately 30-50 MB

## Alternative: EAS Build (Cloud)

If local building doesn't work, you can use Expo's cloud build service:

```bash
cd /app/frontend
npx eas-cli build --platform android --profile preview
```

This requires an Expo account but is much simpler and faster.
