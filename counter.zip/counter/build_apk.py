#!/usr/bin/env python3
"""
Local Android APK Build Script for Expo React Native App
Builds a preview APK that can be installed on Android devices
"""

import os
import sys
import subprocess
import json
from pathlib import Path

class Colors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'

def print_step(message):
    print(f"\n{Colors.OKBLUE}{Colors.BOLD}>>> {message}{Colors.ENDC}")

def print_success(message):
    print(f"{Colors.OKGREEN}✓ {message}{Colors.ENDC}")

def print_error(message):
    print(f"{Colors.FAIL}✗ {message}{Colors.ENDC}")

def print_warning(message):
    print(f"{Colors.WARNING}⚠ {message}{Colors.ENDC}")

def run_command(command, cwd=None, shell=True):
    """Run a shell command and return the result"""
    try:
        print(f"{Colors.OKCYAN}Running: {command}{Colors.ENDC}")
        result = subprocess.run(
            command,
            shell=shell,
            cwd=cwd,
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            print_error(f"Command failed: {command}")
            print(f"Error: {result.stderr}")
            return False
        return True
    except Exception as e:
        print_error(f"Exception running command: {str(e)}")
        return False

def check_prerequisites():
    """Check if required tools are installed"""
    print_step("Checking prerequisites...")
    
    # Check Node.js
    result = subprocess.run("node --version", shell=True, capture_output=True, text=True)
    if result.returncode == 0:
        print_success(f"Node.js installed: {result.stdout.strip()}")
    else:
        print_error("Node.js not found")
        return False
    
    # Check Yarn
    result = subprocess.run("yarn --version", shell=True, capture_output=True, text=True)
    if result.returncode == 0:
        print_success(f"Yarn installed: {result.stdout.strip()}")
    else:
        print_error("Yarn not found")
        return False
    
    return True

def install_android_sdk():
    """Install Android SDK and build tools"""
    print_step("Installing Android SDK and build tools...")
    
    # Install OpenJDK
    print("Installing OpenJDK 17...")
    if not run_command("apt-get update && apt-get install -y openjdk-17-jdk"):
        return False
    
    # Set JAVA_HOME
    java_home = "/usr/lib/jvm/java-17-openjdk-amd64"
    os.environ["JAVA_HOME"] = java_home
    print_success(f"JAVA_HOME set to: {java_home}")
    
    # Install Android SDK
    android_home = "/opt/android-sdk"
    os.environ["ANDROID_HOME"] = android_home
    os.environ["ANDROID_SDK_ROOT"] = android_home
    
    print(f"Setting up Android SDK at: {android_home}")
    
    # Create Android SDK directory
    os.makedirs(android_home, exist_ok=True)
    
    # Download Android command line tools
    cmdline_tools_url = "https://dl.google.com/android/repository/commandlinetools-linux-9477386_latest.zip"
    print("Downloading Android command line tools...")
    
    if not run_command(f"wget -q {cmdline_tools_url} -O /tmp/cmdline-tools.zip"):
        print_error("Failed to download Android command line tools")
        return False
    
    print("Extracting command line tools...")
    if not run_command(f"apt-get install -y unzip"):
        return False
    
    if not run_command(f"unzip -q /tmp/cmdline-tools.zip -d {android_home}"):
        return False
    
    # Move to correct location
    cmdline_tools_path = f"{android_home}/cmdline-tools/latest"
    os.makedirs(cmdline_tools_path, exist_ok=True)
    run_command(f"mv {android_home}/cmdline-tools/* {cmdline_tools_path}/ 2>/dev/null || true")
    
    # Update PATH
    sdk_manager = f"{cmdline_tools_path}/bin/sdkmanager"
    os.environ["PATH"] = f"{cmdline_tools_path}/bin:{os.environ.get('PATH', '')}"
    
    print("Installing Android SDK components...")
    sdk_components = [
        "platform-tools",
        "platforms;android-34",
        "build-tools;34.0.0",
        "ndk;25.1.8937393"
    ]
    
    for component in sdk_components:
        print(f"Installing {component}...")
        if not run_command(f"yes | {sdk_manager} --sdk_root={android_home} '{component}'"):
            print_warning(f"Failed to install {component}, continuing...")
    
    print_success("Android SDK setup complete")
    return True

def update_app_config():
    """Update app.json with Android build configuration"""
    print_step("Updating app configuration...")
    
    app_json_path = "/app/frontend/app.json"
    
    with open(app_json_path, 'r') as f:
        config = json.load(f)
    
    # Update Android configuration
    if "android" not in config["expo"]:
        config["expo"]["android"] = {}
    
    config["expo"]["android"]["package"] = "com.counterapp.app"
    config["expo"]["android"]["versionCode"] = 1
    
    # Save updated config
    with open(app_json_path, 'w') as f:
        json.dump(config, f, indent=2)
    
    print_success("App configuration updated")
    return True

def install_expo_dependencies():
    """Install necessary Expo dependencies"""
    print_step("Installing Expo build dependencies...")
    
    frontend_dir = "/app/frontend"
    
    # Install expo-dev-client and other build dependencies
    packages = [
        "@expo/cli",
        "expo-dev-client"
    ]
    
    for package in packages:
        print(f"Installing {package}...")
        if not run_command(f"yarn add {package}", cwd=frontend_dir):
            print_warning(f"Failed to install {package}, continuing...")
    
    print_success("Dependencies installed")
    return True

def prebuild_expo_app():
    """Run expo prebuild to generate native Android folder"""
    print_step("Running Expo prebuild...")
    
    frontend_dir = "/app/frontend"
    
    # Run expo prebuild
    if not run_command("npx expo prebuild --platform android", cwd=frontend_dir):
        print_error("Expo prebuild failed")
        return False
    
    print_success("Expo prebuild completed")
    return True

def build_apk():
    """Build the Android APK"""
    print_step("Building Android APK...")
    
    android_dir = "/app/frontend/android"
    
    if not os.path.exists(android_dir):
        print_error("Android directory not found. Prebuild may have failed.")
        return False
    
    # Make gradlew executable
    gradlew_path = f"{android_dir}/gradlew"
    if os.path.exists(gradlew_path):
        os.chmod(gradlew_path, 0o755)
    
    # Build APK
    print("Building APK (this may take several minutes)...")
    if not run_command("./gradlew assembleRelease", cwd=android_dir):
        print_error("APK build failed")
        return False
    
    print_success("APK build completed")
    return True

def find_apk():
    """Find and display the built APK location"""
    print_step("Locating built APK...")
    
    apk_search_path = "/app/frontend/android/app/build/outputs/apk/release"
    
    if os.path.exists(apk_search_path):
        apk_files = list(Path(apk_search_path).glob("*.apk"))
        if apk_files:
            apk_path = str(apk_files[0])
            apk_size = os.path.getsize(apk_path) / (1024 * 1024)  # Convert to MB
            
            print_success(f"APK built successfully!")
            print(f"\n{Colors.OKGREEN}{Colors.BOLD}APK Location:{Colors.ENDC}")
            print(f"{Colors.BOLD}{apk_path}{Colors.ENDC}")
            print(f"{Colors.BOLD}Size: {apk_size:.2f} MB{Colors.ENDC}")
            
            # Copy to easy access location
            output_path = "/app/counter-app.apk"
            run_command(f"cp {apk_path} {output_path}")
            print(f"\n{Colors.OKGREEN}APK also copied to: {output_path}{Colors.ENDC}")
            
            return True
    
    print_error("APK file not found")
    return False

def main():
    """Main build process"""
    print(f"\n{Colors.HEADER}{Colors.BOLD}{'='*60}")
    print("  Android APK Build Script for Counter App")
    print(f"{'='*60}{Colors.ENDC}\n")
    
    # Check if running as root (needed for apt-get)
    if os.geteuid() != 0:
        print_error("This script must be run as root (use sudo)")
        sys.exit(1)
    
    steps = [
        ("Checking prerequisites", check_prerequisites),
        ("Installing Android SDK", install_android_sdk),
        ("Updating app configuration", update_app_config),
        ("Installing Expo dependencies", install_expo_dependencies),
        ("Running Expo prebuild", prebuild_expo_app),
        ("Building APK", build_apk),
        ("Locating APK", find_apk),
    ]
    
    for step_name, step_func in steps:
        try:
            if not step_func():
                print_error(f"\n{step_name} failed!")
                print(f"\n{Colors.WARNING}Build process aborted.{Colors.ENDC}")
                sys.exit(1)
        except Exception as e:
            print_error(f"\n{step_name} encountered an error: {str(e)}")
            sys.exit(1)
    
    print(f"\n{Colors.OKGREEN}{Colors.BOLD}{'='*60}")
    print("  Build completed successfully!")
    print(f"{'='*60}{Colors.ENDC}\n")
    
    print(f"{Colors.BOLD}Next steps:{Colors.ENDC}")
    print("1. Download the APK file: /app/counter-app.apk")
    print("2. Transfer it to your Android device")
    print("3. Enable 'Install from unknown sources' in Android settings")
    print("4. Install and run the app")
    print()

if __name__ == "__main__":
    main()
